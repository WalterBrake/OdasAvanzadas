Vue.component('conexion', {
    props: [],
    template: `
        <div class="conexion">
            <slot></slot>
        </div>
    `,
    data(){
        return {
        }
    },
    methods: {
    },
    mounted () {
    }
})